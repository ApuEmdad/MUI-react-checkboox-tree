import React from "react";
import { Box } from "@mui/material";
import { TreeMenu as data } from "../../Assets/data/data";
import TestRoleMenuTree from "./TestRoleMenuTree";

import TreeView from "@mui/lab/TreeView";

import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";

const TestRoleMenuTrees = () => {
  return (
    <div>
      <h1>Test role</h1>
    </div>
  );
};

export default TestRoleMenuTrees;
