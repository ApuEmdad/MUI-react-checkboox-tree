import React from "react";

const TestRoleMenuTree = () => {
  return (
    <div>
      <h4>test role menu tree</h4>
    </div>
  );
};

export default TestRoleMenuTree;
